export type Variant = { id: string; label: string; price: number };
export type Product = {
  id: string;
  name: string;
  blurb: string;
  category: string;
  image: string;
  alt: string;
  featured: boolean;
  objectPos?: string;
  variants: Variant[];
};
export type CartItem = {
  key: string;
  productId: string;
  name: string;
  variantLabel: string;
  price: number;
  qty: number;
};

export const WHATSAPP_NUMBER = "5491122334455";
export const NAME_KEY = "bake-valentina-name";
export const CART_KEY = "bake-valentina-cart";
export const NOTE_KEY = "bake-valentina-note";
export const CATEGORIES = ["Tortas", "Pepas", "Cookies"] as const;
export type Category = (typeof CATEGORIES)[number];

export const PRODUCTS: Product[] = [
  {
    id: "torta-choco",
    name: "Torta de chocolate",
    blurb: "Húmeda, con ganache. Para compartir sin apuro.",
    category: "Tortas",
    image: "/torta-chocolate.jpg",
    alt: "Torta de chocolate casera en plato azul",
    featured: true,
    variants: [
      { id: "18", label: "18 cm", price: 9000 },
      { id: "22", label: "22 cm", price: 12500 },
      { id: "24", label: "24 cm", price: 15000 },
    ],
  },
  {
    id: "torta-vainilla",
    name: "Torta de vainilla y dulce de leche",
    blurb: "La de siempre. Mucho dulce de leche, capas suaves.",
    category: "Tortas",
    image: "/torta-vainilla.jpg",
    alt: "Torta de vainilla con dulce de leche",
    featured: true,
    variants: [
      { id: "18", label: "18 cm", price: 8500 },
      { id: "22", label: "22 cm", price: 11800 },
      { id: "24", label: "24 cm", price: 14200 },
    ],
  },
  {
    id: "torta-limon",
    name: "Torta de limón",
    blurb: "Ácida justo. Bizcochuelo liviano y un almíbar corto.",
    category: "Tortas",
    image: "/torta-limon.jpg",
    alt: "Torta de limón casera con un feta cortado",
    featured: false,
    variants: [
      { id: "18", label: "18 cm", price: 8800 },
      { id: "22", label: "22 cm", price: 12000 },
      { id: "24", label: "24 cm", price: 14500 },
    ],
  },
  {
    id: "torta-marquise",
    name: "Marquise",
    blurb: "Chocolate denso, casi un postre. Sale bien fría.",
    category: "Tortas",
    image: "/torta-chocolate.jpg",
    alt: "Marquise de chocolate",
    featured: false,
    objectPos: "center 80%",
    variants: [
      { id: "18", label: "18 cm", price: 9800 },
      { id: "22", label: "22 cm", price: 13500 },
      { id: "24", label: "24 cm", price: 16200 },
    ],
  },
  {
    id: "pepas-ddl",
    name: "Pepas de dulce de leche",
    blurb: "Crocantes, con el centro bien cargado.",
    category: "Pepas",
    image: "/pepas-ddl.jpg",
    alt: "Pepas de dulce de leche sobre papel de horno",
    featured: true,
    variants: [
      { id: "media", label: "Media docena", price: 2800 },
      { id: "docena", label: "Docena", price: 5200 },
    ],
  },
  {
    id: "pepas-nuez",
    name: "Pepas de nuez",
    blurb: "Manteca y nuez. Se acaban en un rato.",
    category: "Pepas",
    image: "/pepas-nuez.jpg",
    alt: "Pepas de nuez apiladas sobre lienzo",
    featured: true,
    variants: [
      { id: "media", label: "Media docena", price: 3000 },
      { id: "docena", label: "Docena", price: 5600 },
    ],
  },
  {
    id: "pepas-membrillo",
    name: "Pepas de membrillo",
    blurb: "El clásico de lata. Centro de membrillo casero.",
    category: "Pepas",
    image: "/pepas-ddl.jpg",
    alt: "Pepas de membrillo",
    featured: false,
    objectPos: "20% 40%",
    variants: [
      { id: "media", label: "Media docena", price: 2700 },
      { id: "docena", label: "Docena", price: 5000 },
    ],
  },
  {
    id: "pepas-choco",
    name: "Pepas de chocolate",
    blurb: "Masa de cacao y un poquito de dulce al medio.",
    category: "Pepas",
    image: "/pepas-nuez.jpg",
    alt: "Pepas de chocolate",
    featured: false,
    objectPos: "80% 60%",
    variants: [
      { id: "media", label: "Media docena", price: 3200 },
      { id: "docena", label: "Docena", price: 5900 },
    ],
  },
  {
    id: "cookie-choco",
    name: "Cookie de chocolate",
    blurb: "Oscura, borde chewy, centro todavía tibio.",
    category: "Cookies",
    image: "/cookie-chocolate.jpg",
    alt: "Cookie de chocolate en plato de crema",
    featured: true,
    variants: [{ id: "unidad", label: "Por unidad", price: 600 }],
  },
  {
    id: "cookie-chips",
    name: "Cookie con chips",
    blurb: "La clásica. Recién salidas, con el chip derretido.",
    category: "Cookies",
    image: "/cookie-chips.jpg",
    alt: "Cookies con chips de chocolate",
    featured: true,
    variants: [{ id: "unidad", label: "Por unidad", price: 650 }],
  },
  {
    id: "cookie-avena",
    name: "Cookie de avena",
    blurb: "Con pasas. Más desayuno que postre, igual se piden de postre.",
    category: "Cookies",
    image: "/cookie-chips.jpg",
    alt: "Cookie de avena",
    featured: false,
    objectPos: "right center",
    variants: [{ id: "unidad", label: "Por unidad", price: 600 }],
  },
  {
    id: "cookie-brownie",
    name: "Cookie brownie",
    blurb: "Casi un brownie chiquito. Pedí más de una.",
    category: "Cookies",
    image: "/cookie-chocolate.jpg",
    alt: "Cookie brownie",
    featured: false,
    objectPos: "center 30%",
    variants: [{ id: "unidad", label: "Por unidad", price: 700 }],
  },
];

export function formatARS(n: number) {
  return "$" + n.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}

export function catId(cat: string) {
  return `cat-${cat.toLowerCase()}`;
}

export function productsIn(cat: string, featuredOnly = false) {
  return PRODUCTS.filter((p) => p.category === cat && (!featuredOnly || p.featured));
}
