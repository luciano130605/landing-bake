import { useEffect, useMemo, useRef, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Minus, Plus, X } from "lucide-react";

export const Route = createFileRoute("/")({ component: Home });

const WHATSAPP_NUMBER = "5491122334455";
const NAME_KEY = "bake-valentina-name";
const CART_KEY = "bake-valentina-cart";
const NOTE_KEY = "bake-valentina-note";

type Variant = { id: string; label: string; price: number };
type Product = {
  id: string;
  name: string;
  blurb: string;
  category: string;
  image: string;
  alt: string;
  variants: Variant[];
};
type CartItem = {
  key: string;
  productId: string;
  name: string;
  variantLabel: string;
  price: number;
  qty: number;
};

const PRODUCTS: Product[] = [
  {
    id: "torta-choco",
    name: "Torta de chocolate",
    blurb: "Húmeda, con ganache. Para compartir sin apuro.",
    category: "Tortas",
    image: "/torta-chocolate.jpg",
    alt: "Torta de chocolate casera en plato azul",
    variants: [
      { id: "18", label: "18 cm", price: 9000 },
      { id: "22", label: "22 cm", price: 12500 },
      { id: "24", label: "24 cm", price: 15000 },
    ],
  },
  {
    id: "torta-vainilla",
    name: "Torta de vainilla y dulce de leche",
    blurb: "La de siempre. Mucho dulce de leche, capas suaves.",
    category: "Tortas",
    image: "/torta-vainilla.jpg",
    alt: "Torta de vainilla con dulce de leche",
    variants: [
      { id: "18", label: "18 cm", price: 8500 },
      { id: "22", label: "22 cm", price: 11800 },
      { id: "24", label: "24 cm", price: 14200 },
    ],
  },
  {
    id: "pepas-ddl",
    name: "Pepas de dulce de leche",
    blurb: "Crocantes, con el centro bien cargado.",
    category: "Pepas",
    image: "/pepas-ddl.jpg",
    alt: "Pepas de dulce de leche sobre papel de horno",
    variants: [
      { id: "media", label: "Media docena", price: 2800 },
      { id: "docena", label: "Docena", price: 5200 },
    ],
  },
  {
    id: "pepas-nuez",
    name: "Pepas de nuez",
    blurb: "Manteca y nuez. Se acaban en un rato.",
    category: "Pepas",
    image: "/pepas-nuez.jpg",
    alt: "Pepas de nuez apiladas sobre lienzo",
    variants: [
      { id: "media", label: "Media docena", price: 3000 },
      { id: "docena", label: "Docena", price: 5600 },
    ],
  },
  {
    id: "cookie-choco",
    name: "Cookie de chocolate",
    blurb: "Oscura, borde chewy, centro todavía tibio.",
    category: "Cookies",
    image: "/cookie-chocolate.jpg",
    alt: "Cookie de chocolate en plato de crema",
    variants: [{ id: "unidad", label: "Por unidad", price: 600 }],
  },
  {
    id: "cookie-chips",
    name: "Cookie con chips",
    blurb: "La clásica. Recién salidas, con el chip derretido.",
    category: "Cookies",
    image: "/cookie-chips.jpg",
    alt: "Cookies con chips de chocolate",
    variants: [{ id: "unidad", label: "Por unidad", price: 650 }],
  },
];

const CATEGORIES = ["Tortas", "Pepas", "Cookies"];

function formatARS(n: number) {
  return "$" + n.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}

function catId(cat: string) {
  return `cat-${cat.toLowerCase()}`;
}

function Home() {
  const [name, setName] = useState("");
  const [note, setNote] = useState("");
  const [cart, setCart] = useState<CartItem[]>([]);
  const [trayOpen, setTrayOpen] = useState(false);
  const [activeCat, setActiveCat] = useState("Tortas");
  const [shaking, setShaking] = useState(false);
  const [ready, setReady] = useState(false);
  const nameRef = useRef<HTMLInputElement>(null);
  const nameWrapRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    try {
      const storedName = localStorage.getItem(NAME_KEY);
      const storedCart = localStorage.getItem(CART_KEY);
      const storedNote = localStorage.getItem(NOTE_KEY);
      if (storedName) setName(storedName);
      if (storedNote) setNote(storedNote);
      if (storedCart) {
        const parsed = JSON.parse(storedCart) as CartItem[];
        if (Array.isArray(parsed)) setCart(parsed);
      }
    } catch {
      /* ignore */
    }
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    localStorage.setItem(NAME_KEY, name);
  }, [name, ready]);

  useEffect(() => {
    if (!ready) return;
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
  }, [cart, ready]);

  useEffect(() => {
    if (!ready) return;
    localStorage.setItem(NOTE_KEY, note);
  }, [note, ready]);

  useEffect(() => {
    const sections = CATEGORIES.map((c) => document.getElementById(catId(c))).filter(
      (el): el is HTMLElement => !!el,
    );
    if (!sections.length) return;
    const obs = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible?.target.id) {
          const label = CATEGORIES.find((c) => catId(c) === visible.target.id);
          if (label) setActiveCat(label);
        }
      },
      { rootMargin: "-28% 0px -58% 0px", threshold: [0.1, 0.35, 0.6] },
    );
    sections.forEach((s) => obs.observe(s));
    return () => obs.disconnect();
  }, []);

  const count = useMemo(() => cart.reduce((n, i) => n + i.qty, 0), [cart]);
  const total = useMemo(() => cart.reduce((n, i) => n + i.price * i.qty, 0), [cart]);

  function demandName() {
    setShaking(true);
    nameRef.current?.focus();
    nameWrapRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
    window.setTimeout(() => setShaking(false), 450);
  }

  function addItem(product: Product, variant: Variant, qty: number) {
    const key = `${product.id}:${variant.id}`;
    setCart((prev) => {
      const found = prev.find((i) => i.key === key);
      if (found) {
        return prev.map((i) => (i.key === key ? { ...i, qty: i.qty + qty } : i));
      }
      return [
        ...prev,
        {
          key,
          productId: product.id,
          name: product.name,
          variantLabel: variant.label,
          price: variant.price,
          qty,
        },
      ];
    });
  }

  function setQty(key: string, qty: number) {
    setCart((prev) =>
      qty < 1 ? prev.filter((i) => i.key !== key) : prev.map((i) => (i.key === key ? { ...i, qty } : i)),
    );
  }

  function sendWhatsApp() {
    const trimmed = name.trim();
    if (!trimmed) {
      setTrayOpen(false);
      demandName();
      return;
    }
    if (!cart.length) return;

    const lines = cart.map(
      (i) => `• ${i.qty} ${i.name} (${i.variantLabel}) — ${formatARS(i.price * i.qty)}`,
    );
    const extra = note.trim() ? `\n\nNota: ${note.trim()}` : "";
    const mensaje = `Hola! Soy ${trimmed}. Te hago este pedido:\n\n${lines.join("\n")}\n\nTotal: ${formatARS(total)}${extra}`;
    const url = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(mensaje)}`;
    window.open(url, "_blank", "noopener,noreferrer");
  }

  return (
    <div className="grain relative min-h-dvh bg-bg text-fg">
      <span className="mote mote-a" aria-hidden />
      <span className="mote mote-b" aria-hidden />
      <span className="mote mote-c" aria-hidden />
      <span className="mote mote-d" aria-hidden />
      <span className="mote mote-e" aria-hidden />

      <div className="mx-auto max-w-3xl px-5 pb-36 pt-10 sm:px-8 sm:pt-14">
        <header className="text-center">
          <p className="write-in font-display text-lg italic text-accent sm:text-xl">Bake</p>
          <h1 className="mt-1 font-display text-5xl font-semibold tracking-tight text-fg sm:text-6xl">
            {Array.from("Valentina").map((ch, i) => (
              <span
                key={`${ch}-${i}`}
                className="stamp-letter"
                style={{ animationDelay: `${140 + i * 48}ms` }}
              >
                {ch}
              </span>
            ))}
          </h1>
          <div className="rule-track mt-5" aria-hidden>
            <span className="rule-pin" />
          </div>
          <p className="mt-5 text-sm text-muted">Horneado en casa, a pedido</p>
          <p className="mt-1 text-sm text-accent">Pedidos por WhatsApp · 48 hs de anticipación</p>
        </header>

        <div
          ref={nameWrapRef}
          className={`name-wrap mx-auto mt-10 max-w-md ${shaking ? "is-shaking" : ""}`}
        >
          <label htmlFor="customer-name" className="font-display text-base italic text-fg">
            ¿Cómo te llamás?
          </label>
          <input
            id="customer-name"
            ref={nameRef}
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Escribilo acá"
            autoComplete="name"
            className="name-line mt-2 w-full border-0 border-b border-border bg-transparent py-3 font-sans text-lg text-fg placeholder:text-muted/60"
          />
          <p className="mt-2 text-xs text-muted">Va firmado en el mensaje de WhatsApp.</p>
        </div>

        <nav
          className="sticky top-0 z-20 -mx-5 mt-10 flex gap-1 overflow-x-auto bg-bg/90 px-5 py-3 backdrop-blur-sm sm:-mx-8 sm:px-8"
          aria-label="Categorías"
        >
          {CATEGORIES.map((cat) => (
            <a
              key={cat}
              href={`#${catId(cat)}`}
              className={`cat-pill rounded-full px-4 py-2 text-sm font-medium ${activeCat === cat ? "text-fg" : "text-muted"}`}
              data-on={activeCat === cat}
              onClick={(e) => {
                e.preventDefault();
                setActiveCat(cat);
                document.getElementById(catId(cat))?.scrollIntoView({ behavior: "smooth", block: "start" });
              }}
            >
              {cat}
            </a>
          ))}
        </nav>

        {CATEGORIES.map((cat) => (
          <section key={cat} id={catId(cat)} className="mt-10 scroll-mt-16">
            <SectionTitle>{cat}</SectionTitle>
            <div className="mt-6 grid gap-6 sm:grid-cols-2 sm:gap-8">
              {PRODUCTS.filter((p) => p.category === cat).map((p, i) => (
                <ProductCard key={p.id} product={p} delay={i} onAdd={addItem} />
              ))}
            </div>
          </section>
        ))}

        <footer className="mt-20 border-t border-border pt-8 text-center">
          <p className="font-display text-xl font-semibold">Bake Valentina</p>
          <p className="mt-2 text-sm text-muted">Pedidos con 48 hs de anticipación</p>
          <a
            href="https://instagram.com/bakevalentina"
            target="_blank"
            rel="noreferrer"
            className="mt-1 inline-block text-sm text-accent"
          >
            @bakevalentina
          </a>
        </footer>
      </div>

      {count > 0 && !trayOpen ? (
        <div className="bar-in fixed inset-x-0 bottom-0 z-40 px-4 pb-4 pt-2">
          <button
            type="button"
            onClick={() => setTrayOpen(true)}
            className="knead mx-auto flex w-full max-w-3xl items-center justify-between rounded-xl bg-fg px-5 py-4 text-left text-surface shadow-border"
          >
            <span className="text-sm font-medium">
              Tu bandeja · {count} {count === 1 ? "cosa" : "cosas"}
            </span>
            <span className="tabular-nums text-sm font-semibold">{formatARS(total)}</span>
          </button>
        </div>
      ) : null}

      <div
        className={`tray-overlay fixed inset-0 z-50 bg-fg/35 ${trayOpen ? "is-open" : ""}`}
        onClick={() => setTrayOpen(false)}
      />
      <aside
        className={`tray mx-auto w-full max-w-3xl overflow-y-auto rounded-t-xl bg-sheet px-5 pb-8 pt-4 sm:px-8 ${trayOpen ? "is-open" : ""}`}
        role="dialog"
        aria-label="Tu bandeja"
        aria-hidden={!trayOpen}
      >
        <span className="rivet left-4 top-4" aria-hidden />
        <span className="rivet right-4 top-4" aria-hidden />
        <span className="rivet bottom-4 left-4" aria-hidden />
        <span className="rivet bottom-4 right-4" aria-hidden />

        <div className="mx-auto mb-4 h-1.5 w-12 rounded-full bg-fg/20" />
        <div className="flex items-start justify-between gap-4">
          <div>
            <p className="font-display text-2xl font-semibold">La bandeja</p>
            <p className="text-sm text-muted">Revisá y mandalo por WhatsApp.</p>
          </div>
          <button
            type="button"
            onClick={() => setTrayOpen(false)}
            className="knead relative size-11 rounded-full bg-surface text-fg"
            aria-label="Cerrar"
          >
            <X className="mx-auto size-5" strokeWidth={2} />
          </button>
        </div>

        {cart.length === 0 ? (
          <p className="mt-8 font-display text-lg italic text-muted">
            Todavía está vacía. Elegí algo de abajo.
          </p>
        ) : (
          <ul className="mt-6 divide-y divide-border/80">
            {cart.map((item, i) => (
              <li
                key={item.key}
                className="ticket flex items-center justify-between gap-3 py-4"
                style={{ ["--d" as string]: `${i * 55}ms` }}
              >
                <div className="min-w-0">
                  <p className="font-medium leading-snug">{item.name}</p>
                  <p className="text-sm text-muted">
                    {item.variantLabel} · {formatARS(item.price)}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <QtyControl value={item.qty} onChange={(q) => setQty(item.key, q)} allowZero />
                  <span className="w-16 text-right text-sm font-semibold tabular-nums">
                    {formatARS(item.price * item.qty)}
                  </span>
                </div>
              </li>
            ))}
          </ul>
        )}

        <label className="mt-6 block">
          <span className="text-sm font-medium">Una nota, si hace falta</span>
          <textarea
            value={note}
            onChange={(e) => setNote(e.target.value)}
            rows={2}
            placeholder="Sin nuez, para el sábado, etc."
            className="mt-2 w-full resize-none rounded-md border-0 bg-surface px-3 py-3 text-sm text-fg shadow-border placeholder:text-muted/70 focus:outline-2 focus:outline-accent"
          />
        </label>

        <div className="mt-6 flex items-end justify-between">
          <p className="text-sm text-muted">Total</p>
          <p className="font-display text-2xl font-semibold tabular-nums">{formatARS(total)}</p>
        </div>

        <button
          type="button"
          disabled={!cart.length}
          onClick={sendWhatsApp}
          className="knead mt-5 w-full rounded-lg bg-accent py-4 text-center text-base font-semibold text-surface disabled:opacity-40"
        >
          Mandar por WhatsApp
        </button>
        <p className="mt-3 text-center text-xs text-muted">Pedidos con 48 hs de anticipación</p>
      </aside>
    </div>
  );
}

function SectionTitle({ children }: { children: string }) {
  const ref = useRef<SVGSVGElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([e]) => {
        if (e?.isIntersecting) el.classList.add("is-in");
      },
      { threshold: 0.6 },
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  return (
    <div>
      <h2 className="font-display text-3xl font-semibold tracking-tight">{children}</h2>
      <svg ref={ref} className="flour-mark" viewBox="0 0 72 10" aria-hidden>
        <path d="M2 6 C14 2, 24 9, 36 5 S58 2, 70 7" />
      </svg>
    </div>
  );
}

function ProductCard({
  product,
  delay,
  onAdd,
}: {
  product: Product;
  delay: number;
  onAdd: (p: Product, v: Variant, qty: number) => void;
}) {
  const [variantId, setVariantId] = useState(product.variants[0]?.id ?? "");
  const [qty, setQty] = useState(1);
  const [added, setAdded] = useState(false);
  const [burst, setBurst] = useState(0);
  const cardRef = useRef<HTMLElement>(null);
  const variant = product.variants.find((v) => v.id === variantId) ?? product.variants[0];

  useEffect(() => {
    const el = cardRef.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([e]) => {
        if (e?.isIntersecting) {
          el.classList.add("proof");
          obs.disconnect();
        }
      },
      { threshold: 0.18 },
    );
    obs.observe(el);
    const fallback = window.setTimeout(() => el.classList.add("proof"), 900);
    return () => {
      obs.disconnect();
      window.clearTimeout(fallback);
    };
  }, []);

  function handleAdd() {
    if (!variant) return;
    onAdd(product, variant, qty);
    setAdded(true);
    setBurst((n) => n + 1);
    window.setTimeout(() => setAdded(false), 900);
  }

  return (
    <article
      ref={cardRef}
      className="card-surface overflow-hidden rounded-xl opacity-0"
      style={{ animationDelay: `${delay * 90}ms` }}
    >
      <div className="aspect-photo relative overflow-hidden bg-icing">
        <img
          src={product.image}
          alt={product.alt}
          className="food photo-drift h-full w-full object-cover"
        />
      </div>
      <div className="p-5">
        <h3 className="font-display text-xl font-semibold leading-snug">{product.name}</h3>
        <p className="mt-1 text-sm text-muted">{product.blurb}</p>

        <div className="mt-4 flex flex-wrap gap-2">
          {product.variants.map((v) => (
            <button
              key={v.id}
              type="button"
              className="chip rounded-full border border-border bg-surface px-3.5 py-2 text-sm font-medium text-fg"
              data-on={v.id === variantId}
              onClick={() => setVariantId(v.id)}
            >
              {v.label} · {formatARS(v.price)}
            </button>
          ))}
        </div>

        <div className="mt-5 flex items-center justify-between gap-3">
          <QtyControl value={qty} onChange={(q) => setQty(Math.max(1, q))} />
          <div className="relative">
            {burst > 0 ? <FlourBurst key={burst} /> : null}
            <button
              type="button"
              onClick={handleAdd}
              className={`knead rounded-lg px-5 py-3 text-sm font-semibold text-surface ${added ? "added-flash" : "bg-fg"}`}
            >
              {added ? "Sumado" : "Sumar"}
            </button>
          </div>
        </div>
      </div>
    </article>
  );
}

function QtyControl({
  value,
  onChange,
  allowZero = false,
}: {
  value: number;
  onChange: (n: number) => void;
  allowZero?: boolean;
}) {
  const [stamp, setStamp] = useState(false);

  function bump(delta: number) {
    const next = value + delta;
    if (!allowZero && next < 1) return;
    if (allowZero && next < 0) return;
    setStamp(true);
    onChange(next);
    window.setTimeout(() => setStamp(false), 380);
  }

  return (
    <div className="flex items-center gap-1">
      <button
        type="button"
        onClick={() => bump(-1)}
        className="knead size-11 rounded-full border border-border bg-surface text-fg"
        aria-label="Menos"
      >
        <Minus className="mx-auto size-4" strokeWidth={2.2} />
      </button>
      <span className={`qty-stamp w-8 text-center text-base font-semibold ${stamp ? "is-stamping" : ""}`}>
        {value}
      </span>
      <button
        type="button"
        onClick={() => bump(1)}
        className="knead size-11 rounded-full border border-border bg-surface text-fg"
        aria-label="Más"
      >
        <Plus className="mx-auto size-4" strokeWidth={2.2} />
      </button>
    </div>
  );
}

function FlourBurst() {
  const specks = [
    { dx: "-18px", dy: "-22px" },
    { dx: "16px", dy: "-26px" },
    { dx: "-8px", dy: "-34px" },
    { dx: "22px", dy: "-12px" },
    { dx: "-24px", dy: "-8px" },
  ];
  return (
    <>
      {specks.map((s, i) => (
        <span
          key={i}
          className="burst-speck left-1/2 top-1/2"
          style={{
            ["--dx" as string]: s.dx,
            ["--dy" as string]: s.dy,
            animationDelay: `${i * 30}ms`,
          }}
        />
      ))}
    </>
  );
}
